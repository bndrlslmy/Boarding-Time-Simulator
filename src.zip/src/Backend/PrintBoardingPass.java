package Backend;

import java.util.ArrayList;

public interface PrintBoardingPass {

    void printBoardingPass(Passenger[] passengers);
}
